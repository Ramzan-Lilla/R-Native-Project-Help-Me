import { View, Text } from 'react-native'
import React from 'react'

export default function get_customer({navigation}) {
  return (
    <View>
      <Text>Get Customers</Text>
    </View>
  )
}